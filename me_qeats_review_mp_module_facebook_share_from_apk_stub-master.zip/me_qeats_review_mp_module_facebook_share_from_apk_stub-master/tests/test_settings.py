SECRET_KEY = 'uwmtwe9n@i&tr-!or5c2ek_civgw(q4kw6ilgg5)g-bgxmao*h'
ROOT_URLCONF = 'qeats.urls'
